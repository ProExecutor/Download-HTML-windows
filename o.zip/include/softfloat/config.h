#ifndef SOFTFLOAT_CONFIG_H
#define SOFTFLOAT_CONFIG_H

#define CONFIG_SOFTFLOAT
#define FLOATX80
#define FLOAT128
#define INLINE static inline

#define U64(n) n##ULL

#endif